package com.wim.inventoryapp;

/**
 * Manage item table in the database.
 */
public class Item {

    int id;
	String user_email;
    String tag;
    String bndl;
    String bndlnum;


    public Item(int i, String email, String tag, String bundle, String bundlenum) {
        super();
        this.id = i;
		this.user_email = email;
        this.tag = tag;
        this.bndl = bundle;
        this.bndlnum = bundlenum;
    }

    // constructor
    public Item(String email, String tag, String bundle, String bundlenum) {
		this.user_email = email;
        this.tag = tag;
        this.bndl = bundle;
        this.bndlnum = bundlenum;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

	public String getUserEmail() {
        return user_email;
    }

    public void setUserEmail(String user_email) {
        this.user_email = user_email;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getBndl() { return bndl; }

    public void setBndl(String bndl) {
        this.bndl = bndl;
    }

    public String getBndlnum() {
        return bndlnum;
    }

    public void setBndlnum(String bndlnum) {
        this.bndlnum = bndlnum;
    }


}
