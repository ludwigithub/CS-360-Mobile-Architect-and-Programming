package com.wim.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.atomic.AtomicReference;

/**
 * Add  a new item into the database
 * This class is called from by the ItemsListActivity.
 */
public class AddItemActivity extends AppCompatActivity {

    String EmailHolder, TagHolder, BndlHolder, BndlnumHolder;;
    TextView UserEmail;
    ImageButton IncreaseBndlnum, DecreaseBndlnum;
    EditText ItemTagValue, ItemBndlValue, ItemBndlnumValue;
    Button CancelButton, AddItemButton;
	Boolean EmptyHolder = false;
    ItemsSQLiteHandler db;

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_additem);

        // Initiate buttons, textViews, and editText variables
        UserEmail = findViewById(R.id.textViewLoggedUser);
        ItemTagValue = findViewById(R.id.editTextItemTag);
        ItemBndlValue = findViewById(R.id.editTextItemBndl);
        IncreaseBndlnum = findViewById(R.id.itemBndlnumIncrease);
        DecreaseBndlnum = findViewById(R.id.itemBndlnumDecrease);
        ItemBndlnumValue = findViewById(R.id.editTextItemBndlnum);

        CancelButton = findViewById(R.id.addCancelButton);
        AddItemButton = findViewById(R.id.addItemButton);
		db = new ItemsSQLiteHandler(this);

        AtomicReference<Intent> intent = new AtomicReference<>(getIntent());

        // Receiving user email send by ItemsListActivity
        EmailHolder = intent.get().getStringExtra(ItemsListActivity.UserEmail);

        // Setting user email on textViewLoggedUser
        UserEmail.setText(getString(R.string.logged_user, EmailHolder));

        // Adding click listener to itemBndlnumIncrease forgotPasswordButton
        IncreaseBndlnum.setOnClickListener(view -> {
            int input = 0, total;

            String value = ItemBndlnumValue.getText().toString().trim();

            if (!value.isEmpty()) {
                input = Integer.parseInt(value);
            }

            total = input + 1;
            ItemBndlnumValue.setText(String.valueOf(total));
        });


        // Adding click listener to itemQtyDecrease forgotPasswordButton
        DecreaseBndlnum.setOnClickListener(view -> {
            int input, total;

            String qty = ItemBndlnumValue.getText().toString().trim();

            if (qty.equals("0")) {
                Toast.makeText(this, "Item Quantity is Zero", Toast.LENGTH_LONG).show();
            } else {
                input = Integer.parseInt(qty);
                total = input - 1;
                ItemBndlnumValue.setText(String.valueOf(total));
            }
        });


        // Adding click listener to addCancelButton
        CancelButton.setOnClickListener(view -> {
            // Going back to ItemsListActivity after cancel adding item
			Intent add = new Intent();
			setResult(0, add);
            this.finish();
        });

        // Adding click listener to addItemButton and pass data to ItemsListActivity
        AddItemButton.setOnClickListener(view -> InsertItemIntoDatabase());
    }

    // Insert item data into database and send data to ItemsListActivity
    public void InsertItemIntoDatabase() {
		String message = CheckEditTextNotEmpty();

        if (!EmptyHolder) {
       	  	String email = EmailHolder;
            String tag = TagHolder;
            String bndl = BndlHolder;
            String bndlnum = BndlnumHolder;

        	Item item = new Item(email, tag, bndl, bndlnum);
        	db.createItem(item);

            // Display toast message after insert in table
            Toast.makeText(this,"Item Added Successfully", Toast.LENGTH_LONG).show();

            // Close AddItemActivity
			Intent add = new Intent();
			setResult(RESULT_OK, add);
            this.finish();
        } else {
            // Display toast message if item tag is empty and focus the field
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Checking item description is not empty
    public String CheckEditTextNotEmpty() {
        // Getting value from fields and storing into string variable
		String message = "";
        TagHolder = ItemTagValue.getText().toString().trim();
        BndlHolder = ItemBndlValue.getText().toString().trim();
        BndlnumHolder = ItemBndlnumValue.getText().toString().trim();

        if (TagHolder.isEmpty()) {
			ItemTagValue.requestFocus();
            EmptyHolder = true;
            message = "Item TAG is Empty";
        } else if (BndlHolder.isEmpty()){
			ItemBndlValue.requestFocus();
			EmptyHolder = true;
			message = "Item Bundle is Empty";
        } else if (BndlnumHolder.isEmpty()){
            ItemBndlnumValue.requestFocus();
            EmptyHolder = true;
            message = "Item Bundle Number is Empty";
        } else {
        	EmptyHolder = false;
		}
        return message;
    }

}
